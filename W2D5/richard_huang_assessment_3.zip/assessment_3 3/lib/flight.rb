class Flight
    attr_reader :passengers
    def initialize(flight_num, capacity)
        @flight_number = flight_num
        @capacity = capacity 
        @passengers = []
    end

    def full?
        return true if @passengers.length == @capacity
        return false if @passengers.length < @capacity
    end

    def board_passenger(pass_instance)
        if pass_instance.has_flight?(@flight_number) && !full? 
            @passengers << pass_instance
        end
    end

    def list_passengers
        @passengers.map(&:name)
    end

    def [](idx)
        @passengers[idx]
    end

    def <<(pass_instance)
        board_passenger(pass_instance)
    end
end